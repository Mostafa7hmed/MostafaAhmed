package com.example.flutter_auth

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {

}
